<?php
/*
Plugin Name: Hotel Information
Description: This is crud plugin. 
Version: 1
Author: Sakib Ahmed
Author URI: 
*/
  
  
namespace image_uploader;

function register_metaboxes() {
	add_meta_box('image_metabox', 'Image Uploader', __NAMESPACE__ . '\image_uploader_callback');
}
add_action( 'add_meta_boxes', __NAMESPACE__ . '\register_metaboxes' );

function register_admin_script() {
	wp_enqueue_script( 'wp_img_upload', plugin_dir_url( __FILE__ ) . '/image-upload.js', array('jquery', 'media-upload'), '0.0.2', true );
	wp_localize_script( 'wp_img_upload', 'customUploads', array( 'imageData' => get_post_meta( get_the_ID(), 'custom_image_data', true ) ) );
}
add_action( 'admin_enqueue_scripts', __NAMESPACE__ . '\register_admin_script' );

function image_uploader_callback( $post_id ) {
	wp_nonce_field( basename( __FILE__ ), 'custom_image_nonce' ); ?>

	<div id="metabox_wrapper">
		<img id="image-tag">
		<input type="hidden" id="img-hidden-field" name="custom_image_data">
		<input type="button" id="image-upload-button" class="button" value="Add Image">
		<input type="button" id="image-delete-button" class="button" value="Delete Image">
	</div>

	<?php
}

function save_custom_image( $post_id ) {
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'custom_image_nonce' ] ) && wp_verify_nonce( $_POST[ 'custom_image_nonce' ], basename( __FILE__ ) ) );

	// Exits script depending on save status
	if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
		return;
	}

	if ( isset( $_POST[ 'custom_image_data' ] ) ) {
		$image_data = json_decode( stripslashes( $_POST[ 'custom_image_data' ] ) );
		if ( is_object( $image_data[0] ) ) {
			$image_data = array( 'id' => intval( $image_data[0]->id ), 'src' => esc_url_raw( $image_data[0]->url
			) );
		} else {
			$image_data = [];
		}

		update_post_meta( $post_id, 'custom_image_data', $image_data );
	}

}
add_action( 'save_post', __NAMESPACE__ . '\save_custom_image' );

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
function hotel_info_ajaxinsert()
	{
		global $wpdb;
		$county 		= $_POST["county"];
		var_dump($county );
		$hotel_name 	= $_POST["hotel_name"];
		
		//$image_1 		= ($_FILES["image_1"]["tmp_name"]);
		
		$image 				= ($_FILES["image_1"]["name"]);
		$theme_image 		= ($_FILES["image_1"]["tmp_name"]);
		$image_info 		= getimagesize($_FILES["image_1"]["tmp_name"]);

		$bin_string 		= file_get_contents("$theme_image"); 
		$theme_image_enc 	= base64_encode($bin_string); 


		$org_w  = $image_info[0]; // current width as found in image file
		$org_h = $image_info[1]; // current height as found in image file
			
		$WIDTH 		= 900; // The size of your new image
		$HEIGHT		= 600;  // The size of your new image


		$theme_image_little 	= imagecreatefromstring(base64_decode($theme_image_enc));
		$image_little 			= imagecreatetruecolor($WIDTH, $HEIGHT);
		imagecopyresampled($image_little, $theme_image_little, 0, 0, 0, 0, $WIDTH, $HEIGHT, $org_w, $org_h);


		ImageJPEG($image_little , $image, 5); 
		ob_start();
		imagepng($image_little);
		$contents =  ob_get_contents();
		var_dump($contents);
		ob_end_clean();

		echo $aencode1 = base64_encode($contents);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		$image_2 		= ($_FILES["image_2"]["tmp_name"]);
		$image_3 		= ($_FILES["image_3"]["tmp_name"]);
		
		
		$image_4 		= ($_FILES["image_4"]["tmp_name"]);
		$image_5 		= ($_FILES["image_5"]["tmp_name"]);
		$image_6 		= ($_FILES["image_6"]["tmp_name"]);
		$image_7 		= ($_FILES["image_7"]["tmp_name"]);
		$image_8 		= ($_FILES["image_8"]["tmp_name"]);
		
		
		
		
		
		
		
		
		
		
		
		
		$kids_des 		= $_POST["kids_des"];
		$adults_des 	= $_POST["adults_des"];
		$hotel_des 		= $_POST["hotel_des"];
		$lat 			= $_POST["lat"];
		$lang 			= $_POST["lang"];
				
				var_dump($hotel_des );


		//image 1
		//$bin_string_1 = file_get_contents("$image_1"); 
		//$aencode1 = base64_encode($bin_string_1);
		//var_dump($aencode1);
		//image 2
		$bin_string_2 = file_get_contents("$image_2"); 
		$aencode2 = base64_encode($bin_string_2);
		//var_dump($aencode2);
		//image 3
		$bin_string_3 = file_get_contents("$image_3"); 
		$aencode3 = base64_encode($bin_string_3);
		//var_dump($aencode3);
		
		
		
		
		//image 4
		$bin_string_4 = file_get_contents("$image_4"); 
		$aencode4 = base64_encode($bin_string_4);
		//var_dump($aencode3);
		//image 5
		$bin_string_5 = file_get_contents("$image_5"); 
		$aencode5 = base64_encode($bin_string_5);
		//var_dump($aencode3);
		//image 6
		$bin_string_6 = file_get_contents("$image_6"); 
		$aencode6 = base64_encode($bin_string_6);
		//var_dump($aencode3);
		//image 7
		$bin_string_7 = file_get_contents("$image_7"); 
		$aencode7 = base64_encode($bin_string_7);
		//var_dump($aencode3);
		//image 8
		$bin_string_8 = file_get_contents("$image_8"); 
		$aencode8 = base64_encode($bin_string_8);
		//var_dump($aencode3);

		
		
		
		
		
		
		
		
		
		
		
		
		$wpdb->insert(
			'hotels', //table
			array(
			'county' 		=> $county,
			'hotel' 		=> $hotel_name,
			'image_1' 		=> $aencode1,
			'image_2' 		=> $aencode2,
			'image_3' 		=> $aencode3,
			'image_4' 		=> $aencode4,
			'image_5' 		=> $aencode5,
			'image_6' 		=> $aencode6,
			'image_7' 		=> $aencode7,
			'image_8' 		=> $aencode8,
			'kids' 			=> $kids_des,
			'adult' 		=> $adults_des, 
			'description' 	=> $hotel_des,
			'lat' 			=> $lat,
			'lang' 			=> $lang) 
		  //array('%s', '%s') //data format
		);
		$message.="Data inserted";
		}


	add_action( 'wp_ajax_hotel_info_ajaxinsert', 'hotel_info_ajaxinsert' );
	add_action('wp_ajax_nopriv_hotel_info_ajaxinsert', 'hotel_info_ajaxinsert');

	


//////////////////AJAX UPDATE/////////////////////////
 function hotel_info_ajaxupdate()
	{
		global $wpdb;
		$table_name = "hotels";
		
		$id 			= $_POST["id"];
		$county 		= $_POST["county"];
		$hotel_name 	= $_POST["hotel_name"];
		$image_1 		= ($_FILES["image_1"]["tmp_name"]);
		$image_2 		= ($_FILES["image_2"]["tmp_name"]);
		$image_3 		= ($_FILES["image_3"]["tmp_name"]);
		$image_4 		= ($_FILES["image_4"]["tmp_name"]);
		$image_5 		= ($_FILES["image_5"]["tmp_name"]);
		$image_6 		= ($_FILES["image_6"]["tmp_name"]);
		$image_7 		= ($_FILES["image_7"]["tmp_name"]);
		$image_8 		= ($_FILES["image_8"]["tmp_name"]);
		$kids_des 		= $_POST["kids_desu"];
		$adults_des 	= $_POST["adults_desu"];
		$hotel_des 		= $_POST["hotel_desu"];
		$lat 			= $_POST["lat"];
		$lang 			= $_POST["lang"];
		var_dump($kids_des);
		var_dump($adults_des);
		var_dump($hotel_des);
		
		//image 1
		$bin_string_1 = file_get_contents("$image_1"); 
		$aencode1 = base64_encode($bin_string_1);
		var_dump($aencode1);
		//image 1
		$bin_string_2 = file_get_contents("$image_2"); 
		$aencode2 = base64_encode($bin_string_2);
		var_dump($aencode2);
		//image 1
		$bin_string_3 = file_get_contents("$image_3"); 
		$aencode3 = base64_encode($bin_string_3);
		var_dump($aencode3);
		
		//image 4
		$bin_string_4 = file_get_contents("$image_4"); 
		$aencode4 = base64_encode($bin_string_4);
		//var_dump($aencode3);
		//image 5
		$bin_string_5 = file_get_contents("$image_5"); 
		$aencode5 = base64_encode($bin_string_5);
		//var_dump($aencode3);
		//image 6
		$bin_string_6 = file_get_contents("$image_6"); 
		$aencode6 = base64_encode($bin_string_6);
		//var_dump($aencode3);
		//image 7
		$bin_string_7 = file_get_contents("$image_7"); 
		$aencode7 = base64_encode($bin_string_7);
		//var_dump($aencode3);
		//image 8
		$bin_string_8 = file_get_contents("$image_8"); 
		$aencode8 = base64_encode($bin_string_8);
		//var_dump($aencode3);
			
		if(!empty($image_1 or $image_2 or $image_3)){
		//update with image
				$result = $wpdb->update(
						$table_name, //table
						array(
							'hotel' 		=> $hotel_name,
							'image_1' 		=> $aencode1,
							'image_2' 		=> $aencode2,
							'image_3' 		=> $aencode3,
							'image_4' 		=> $aencode4,
							'image_5' 		=> $aencode5,
							'image_6' 		=> $aencode6,
							'image_7' 		=> $aencode7,
							'image_8' 		=> $aencode8,
							'kids' 			=> $kids_des,
							'adult' 		=> $adults_des,
							'description' 	=> $hotel_des,
							'lat' 			=> $lat,
							'lang' 			=> $lang), //data
						array('id' => $id) //where

						);
		} 
		else {
		//update without image
				$result = $wpdb->update(
						$table_name, //table
						array(
							'hotel' 		=> $hotel_name,
							'kids' 			=> $kids_des,
							'adult' 		=> $adults_des,
							'description' 	=> $hotel_des,
							'lat' 			=> $lat,
							'lang' 			=> $lang), //data
						array('id' => $id) //where

						);
		}				
			
	}
	add_action( 'wp_ajax_hotel_info_ajaxupdate', 'hotel_info_ajaxupdate' );
	add_action('wp_ajax_nopriv_hotel_info_ajaxupdate', 'hotel_info_ajaxupdate'); 




////////////////////////////////////////////




//menu items
add_action('admin_menu','hotel_info_wp_modifymenu');
function hotel_info_wp_modifymenu() {
	
	//this is the main item for the menu
	add_menu_page('Hotel information plugin', //page title
	'Hotel Information', //menu title
	'manage_options', //capabilities
	'hotel_info_data_list', //menu slug
	'hotel_info_data_list', //function,
	'dashicons-building'//icon
	);
	
	//this is a submenu
	add_submenu_page('hotel_info_data_list', //parent slug
	'Add New Hotel Info ', //page title
	'Add New Hotel Info ', //menu title
	'manage_options', //capability
	'hotel_info_data_create', //menu slug
	'hotel_info_data_create'); //function
	
	//this submenu is HIDDEN, however, we need to add it anyways
	add_submenu_page(null, //parent slug
	'Update', //page title
	'Update', //menu title
	'manage_options', //capability
	'hotel_info_data_update', //menu slug
	'hotel_info_data_update'); //function
	
	//this submenu is HIDDEN, however, we need to add it anyways
	add_submenu_page(null, //parent slug
	'Delete', //page title
	'Delete', //menu title
	'manage_options', //capability
	'hotel_info_data_delete', //menu slug
	'hotel_info_data_delete'); //function
}



//add js and css//
function hotel_info_loadOurJsfile()
{
	
	wp_enqueue_script('demo-ajax', plugin_dir_url(__FILE__).'js/demo-ajax.js', array('jquery'), '1.0',TRUE);
	wp_enqueue_script('els-ajax-def', plugin_dir_url(__FILE__).'js/els-ajax-def.js', array('jquery'), '1.1', TRUE);
	wp_enqueue_script('bootstrap.min.js', plugin_dir_url(__FILE__).'js/bootstrap.min.js', array('jquery'), '1.1', TRUE);
	
	
	wp_enqueue_style('style', plugin_dir_url(__FILE__).'css/style.css', '', '1.1');
	wp_enqueue_style('bootstrap.min', plugin_dir_url(__FILE__).'css/bootstrap.min.css', '', '1.1');
	wp_enqueue_style('responsive.css', plugin_dir_url(__FILE__).'css/responsive.css', '', '1.1');
}
add_action('admin_enqueue_scripts', 'hotel_info_loadOurJsfile');


//add js and css end//

define('hotel_ROOTDIR', plugin_dir_path(__FILE__));
require_once(hotel_ROOTDIR . 'list.php');
require_once(hotel_ROOTDIR . 'create.php');
require_once(hotel_ROOTDIR . 'update.php');
require_once(hotel_ROOTDIR . 'delete.php');

 function hotel_info_limit($limit){
	$post_content= explode(" ", get_the_content());
	$less_content=array_slice($post_content,0,$limit);
  
	echo implode (" ",$less_content);
 }


?>